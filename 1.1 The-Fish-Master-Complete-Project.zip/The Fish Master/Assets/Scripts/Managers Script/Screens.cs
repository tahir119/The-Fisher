﻿public enum Screens
{
    MAIN,
    END,
    GAME,
    RETURN
}
